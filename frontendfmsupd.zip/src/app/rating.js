const icons=document.querySelectorAll('.fas');
let rated=false;
icons.forEach((icon,index)=>{
   
    
    icon.addEventListener('mouseenter',()=>{
        icons.forEach((icon,i)=>{ if(i<=index && !rated) icon.classList.add('rating') });
    });
    icon.addEventListener('mouseleave',()=>{
        icons.forEach((icon,i)=>{if(i<=index && !rated) icon.classList.remove('rating')});
    });

});

icons.forEach(icon=>{

    icon.addEventListener('click',()=>{ rated=true})
});