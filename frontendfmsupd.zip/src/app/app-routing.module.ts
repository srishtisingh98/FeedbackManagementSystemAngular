import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { LoginComponent } from './components/login/login.component';
import { FAQComponent } from './components/faq/faq.component';
import { EmployeeAdminComponent } from './components/employee-admin/employee-admin.component';
import { EmployeeFacultyComponent } from './components/employee-faculty/employee-faculty.component';
import { EmployeeParticipantComponent } from './components/employee-participant/employee-participant.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AddCourseComponent } from './components/add-course/add-course.component';
import { ShowCourseComponent } from './components/show-course/show-course.component';
import { AddTrainerComponent } from './components/add-trainer/add-trainer.component';
import { ShowTrainerComponent } from './components/show-trainer/show-trainer.component';
import { FacultyDashboardComponent } from './components/faculty-dashboard/faculty-dashboard.component';
import { AddProgramComponent } from './components/add-program/add-program.component';
import { ParticipantDashboardComponent } from './components/participant-dashboard/participant-dashboard.component';
import { GiveFeedbackComponent } from './components/give-feedback/give-feedback.component';
import { UpdateCourseComponent } from './components/update-course/update-course.component';
import { UpdateProgramComponent } from './components/update-program/update-program.component';
import { ShowProgramComponent } from './components/show-program/show-program.component';
import { ShowFeedbackComponent } from './components/show-feedback/show-feedback.component';
import { HomeIconComponent } from './home-icon/home-icon.component';

const routes: Routes = [
  {
    path:'about-us', component: AboutUsComponent
  },
  {
    path:'contact-us', component: ContactUsComponent
  },
  {
    path:'home', component: HomePageComponent
  },
  {
    path:'login', component: LoginComponent
  },
  {
    path:'employee-admin', component: EmployeeAdminComponent
  },
  {
    path:'faculty-dashboard', component: FacultyDashboardComponent
  },
  {
    path:'update-course', component: UpdateCourseComponent
  },
  {
    path:'update-program', component: UpdateProgramComponent
  },
  {
    path:'show-feedback', component: ShowFeedbackComponent
  },
  {
    path:'participant-dashboard', component: ParticipantDashboardComponent
  },
  {
    path:'home-icon', component: HomeIconComponent
  },
  {
    path:'add-course', component: AddCourseComponent
  },
  {
    path:'employee-faculty', component: EmployeeFacultyComponent
  },
  {
    path:'give-feedback', component: GiveFeedbackComponent
  },
  {
    path:'employee-participant', component: EmployeeParticipantComponent
  },
  {
    path:'admin-dashboard', component: AdminDashboardComponent
  },
  {
    path:'show-course', component: ShowCourseComponent
  },
  {
    path:'show-program', component: ShowProgramComponent
  },
  {
    path:'add-program', component: AddProgramComponent
  },
  {
    path:'add-trainer', component: AddTrainerComponent
  },
  {
    path:'show-trainer', component: ShowTrainerComponent
  },
  {
    path:'faq', component: FAQComponent
  },
  {path: '', redirectTo: '/home', pathMatch: 'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'enabled',
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { 


}
