export interface BasicResponse {
    status: boolean;
    msg: string;
}
