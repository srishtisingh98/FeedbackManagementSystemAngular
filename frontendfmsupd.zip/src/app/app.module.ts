import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { FAQComponent } from './components/faq/faq.component';
import { FooterComponent } from './components/footer/footer.component';
import { MainComponent } from './components/main/main.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule } from '@angular/forms';
import { EmployeeAdminComponent } from './components/employee-admin/employee-admin.component';
import { EmployeeFacultyComponent } from './components/employee-faculty/employee-faculty.component';
import { EmployeeParticipantComponent } from './components/employee-participant/employee-participant.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AddCourseComponent } from './components/add-course/add-course.component';
import { ShowCourseComponent } from './components/show-course/show-course.component';
import { AddTrainerComponent } from './components/add-trainer/add-trainer.component';
import { ShowTrainerComponent } from './components/show-trainer/show-trainer.component';
import { FacultyDashboardComponent } from './components/faculty-dashboard/faculty-dashboard.component';
import { AddProgramComponent } from './components/add-program/add-program.component';

import { GiveFeedbackComponent } from './components/give-feedback/give-feedback.component';
import { UpdateCourseComponent } from './components/update-course/update-course.component';
import { ShowProgramComponent } from './components/show-program/show-program.component';
import { UpdateProgramComponent } from './components/update-program/update-program.component';
import { ShowFeedbackComponent } from './components/show-feedback/show-feedback.component';
import { HomeIconComponent } from './home-icon/home-icon.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ParticipantDashboardComponent } from './components/participant-dashboard/participant-dashboard.component';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomePageComponent,
    AboutUsComponent,
    ContactUsComponent,
    LoginComponent,
    FAQComponent,
    MainComponent,
    EmployeeAdminComponent,
    EmployeeFacultyComponent,
    EmployeeParticipantComponent,
    AdminDashboardComponent,
    AddCourseComponent,
    ShowCourseComponent,
    AddTrainerComponent,
    ShowTrainerComponent,
    FacultyDashboardComponent,
    AddProgramComponent,
    ParticipantDashboardComponent,
    GiveFeedbackComponent,
    UpdateCourseComponent,
    ShowProgramComponent,
    UpdateProgramComponent,
    ShowFeedbackComponent,
    HomeIconComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
