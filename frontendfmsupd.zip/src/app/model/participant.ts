import { Course } from "./course";
import { Employee } from "./employee";
import { Feedback } from "./feedback";
import { Program } from "./program";

export class Participant{
    participantId:number;
    partName:string;
    password:string;
    course: Course = new Course(0,'','',0);
    employee: Employee = new Employee(0,'','','');
    program:Program=new Program(0,new Date(),new Date(),this.course, this.employee);
    //feedback:Feedback=new Feedback(0,this.program,0,0,0,0,0,'','');
    //if necessary remove program in this entity where as in feedback we are giving program id
    constructor(participantId:number,
        partName:string,
        password:string,
        ){
        this.participantId=participantId;
        this.partName=partName;
        this.password=password;
        // this.feedback=feedback;
        // this.program=program;
    }
    
}