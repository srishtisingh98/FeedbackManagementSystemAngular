import { Course } from "./course";
import { Employee } from "./employee";

export class Program {
    public trainingId: number;
    public startDate: Date;
    public endDate: Date;
    public course: Course;
    public faculty: Employee;

    constructor(trainingId: number, startDate: Date, endDate: Date, course: Course, faculty: Employee ){
            this.trainingId= trainingId;
            this.startDate= startDate;
            this.endDate= endDate;
            this.course = new Course(0,'','',0);
            this.faculty = new Employee(0,'','','');

    }

}