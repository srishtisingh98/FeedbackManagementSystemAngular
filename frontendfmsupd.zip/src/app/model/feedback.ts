import { Participant } from "./participant";
import { Program } from "./program";

export class Feedback{
    participant:Participant=new Participant(0,'','');
    feedbackId : number;
    trainingId:number;
    feedbackCriteria1 :number;
    feedbackCriteria2 : number;
    feedbackCriteria3 : number;
    feedbackCriteria4 : number;
    feedbackCriteria5 : number;
    comments : string;
    suggestions : string;

    constructor ( feedbackId :number, trainingId : number, feedbackCriteria1 : number, feedbackCriteria2 : number,
        feedbackCriteria3 :number, feedbackCriteria4 : number, feedbackCriteria5 : number, 
        comments :string, suggestions : string){
            this.feedbackId = feedbackId;
            this.trainingId = trainingId;
            this.feedbackCriteria1 = feedbackCriteria1;
            this.feedbackCriteria2 = feedbackCriteria2;
            this.feedbackCriteria3 = feedbackCriteria3;
            this.feedbackCriteria4 = feedbackCriteria4;
            this.feedbackCriteria5 = feedbackCriteria5;
            this.suggestions= suggestions;
            this.comments = comments;  

    }

}