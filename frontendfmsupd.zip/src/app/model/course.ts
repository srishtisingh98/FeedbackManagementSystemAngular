export class Course {
    public courseId : number;
    public courseName : string;
    public courseDescription : string;
    public noOfDays : number;

    constructor(courseId : number, courseName : string, courseDescription : string,
        noOfDays :number){
            this.courseId = courseId;
            this.courseName = courseName;
            this.courseDescription = courseDescription;
            this.noOfDays = noOfDays;
    }
}