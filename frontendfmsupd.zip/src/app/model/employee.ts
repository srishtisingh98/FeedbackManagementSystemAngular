export class Employee{
    employeeId:number;
    empName :string;
    password :string;
    role :string;

    constructor(employeeId:number, empName: string,
         password: string, role: string ){
            this.employeeId = employeeId;
            this.empName = empName;
            this.password = password;
            this.role = role;
    }
}