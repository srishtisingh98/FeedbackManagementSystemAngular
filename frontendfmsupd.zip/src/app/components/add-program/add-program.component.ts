import { Component, OnInit } from '@angular/core';
import { ProgramService } from 'src/app/service/program-service';
import { Router } from '@angular/router';
import { Program } from 'src/app/model/program';
import { Course } from 'src/app/model/course';
import { Employee } from 'src/app/model/employee';
@Component({
  selector: 'app-add-program',
  templateUrl: './add-program.component.html',
  styleUrls: ['./add-program.component.css']
})
export class AddProgramComponent implements OnInit {

  program: any;
  router : Router;
  success:boolean=false;
  minDate: Date;
  maxDate: Date;
  course: Course = new Course(0,'','',0);
  employee: Employee = new Employee(0,'','','');
 // program:Program=new Program(0,new Date(),new Date(),this.course, this.employee);
  constructor(router: Router, private programServ : ProgramService) { 
    this.router = router;
    this.minDate= new Date();
    this.maxDate= new Date();
    this.minDate.setDate(this.minDate.getDate());
    this.maxDate.setDate(this.maxDate.getDate() + 70)
  }
  
  ngOnInit(): void {
  }
  // empId = this.employee.employeeId;
  addProgram(data:any){
    this.program= new Program(0 ,data.value.startDate, data.value.endDate, data.value.course.courseId, data.value.employee.employeeId);
      this.programServ.program.push(data.value);
      this.router.navigate([
        '/show-program'
      ]);
      console.log(data);
 
      
  }
  }
