import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee-service';
@Component({
  selector: 'app-employee-participant',
  templateUrl: './employee-participant.component.html',
  styleUrls: ['./employee-participant.component.css']
})
export class EmployeeParticipantComponent implements OnInit {

  employee:any;
  router:Router;
  success : Boolean= false;
  constructor(private employeeServ : EmployeeService, router:Router) { 
  this.router= router;
  }

  ngOnInit(): void {
  }

  loginEmployee(data: any) {
    this.employee = new Employee(data.value.id, "", data.value.password, "");
    this.employeeServ.loginEmployee(this.employee)
    console.log(this.employee);
    setTimeout(
      ()=>{

        console.log(this.employee);
        if(this.employee.role==""){
          console.log("Wrong Password");
          this.success = true;
        } if(this.employee.role == "PARTICIPANT") {
            this.router.navigate([
            '/participant-dashboard'
          ]);
        }
      }, 
      1000
    ); 

}
}