import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/model/feedback';
import { Participant } from 'src/app/model/participant';
import { Program } from 'src/app/model/program';
import { FeedbackService } from 'src/app/service/feedback-service';
import { ProgramService } from 'src/app/service/program-service';

@Component({
  selector: 'app-give-feedback',
  templateUrl: './give-feedback.component.html',
  styleUrls: ['./give-feedback.component.css']
})
export class GiveFeedbackComponent implements OnInit {
  // alert:boolean=false;
  // feedback:Feedback
  // program:Program
 
  // participant:Participant=new Participant(0,'','');
  
  // feedbackService:FeedbackService;
  // programService:ProgramService;
  // createdFlag:boolean=false;
  // router:Router;
  // constructor(feedbackService:FeedbackService,router:Router,programService:ProgramService) {
  //   this.feedbackService=feedbackService; 
  //   // this.questionService=questionService;
  //   this.router=router;
  //   this.programService=programService;
  

 
  ngOnInit(): void {
  }
  // onSubmit(data: any){

  // this.participant= new Participant(0,'','');
  // this.feedback= new Feedback(data.feedbackId,data.trainingId,data.feedbackCriteria1,data.feedbackCriteria2,
  //   data.feedbackCriteria3,data.feedbackCriteria4,data.feedbackCriteria5,data.comments,data.suggestions);
  // this.feedback.participant= this.participant;
  // console.log("adding"+this.feedback)
  // this.feedbackService.addFeedback(this.feedback);
  // this.createdFlag=true;
  // alert("Thankyou for your feedback");
  // }
  
  // closeAlert()
  // {
  //   this.alert=false;
  // }
}

  // feedback: Feedback;
  // router : Router;
  // feedbackServ : FeedbackService;
  // createdFlag:boolean=false;
  // constructor(router: Router, feedbackServ : FeedbackService,) { 
  //   this.router = router;
  //   this.feedback= new Feedback(0,0,0,0,0,0,0,'','');
  //   this.feedbackServ= feedbackServ;
  // }
  
  // ngOnInit(): void {
  // }
  // onSubmit(data:any){
  //   this.feedback= new Feedback(data.feedbackId, data.trainingId,
  //   data.feedbackCriteria1.values,data.feedbackCriteria2,data.feedbackCriteria3,data.feedbackCriteria4,
  //   data.feedbackCriteria5,data.comments,data.suggestions);
  //   //this.createdEmployee.password=data.password;
  //   console.log('adding: '+this.feedback);
  //   this.feedbackServ.addFeedback(this.feedback);
  //   this.createdFlag=true;
    
  // }

