import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../service/employee-service';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';

@Component({
  selector: 'app-employee-admin',
  templateUrl: './employee-admin.component.html',
  styleUrls: ['./employee-admin.component.css']
})
 export class EmployeeAdminComponent implements OnInit {

  employee:any;
  router:Router;
  success : Boolean= false;
  constructor(private employeeServ : EmployeeService, router:Router) { 
  this.router= router;
  }

  ngOnInit(): void {
  }

  loginEmployee(data: any) {
    this.employee = new Employee(data.value.id, "", data.value.password, "");
    this.employeeServ.loginEmployee(this.employee)
    console.log(this.employee);
    setTimeout(
      ()=>{

        console.log(this.employee);
        if(this.employee.role==""){
          console.log("Wrong Password");
          this.success = true;
        } if(this.employee.role == "ADMIN") {
            this.router.navigate([
            '/admin-dashboard'
          ]);
        }
      }, 
      1000
    ); 

}
}