import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Course } from 'src/app/model/course';
import { CourseService } from 'src/app/service/course-service';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {
  course: Course
  router:Router;
  constructor(private route:ActivatedRoute, private courseService:CourseService, router:Router) {
    this.course=new Course(0,'','',0);
    this.router = router;
   }

  ngOnInit(): void {
    let id = this.route.snapshot.params['id'];
    this.course=this.courseService.getCourse(id);
    console.log(this.course);
  }
  updateCourse(course:Course){
    if(this.courseService.idExists(course)){
       alert('Course updated successfully');
       this.router.navigate([
        'show-course'
      ]);
    }
    else{
      alert("Course not found");
      this.router.navigate([
        'show-course'
      ]);
    }
  
   }

}
