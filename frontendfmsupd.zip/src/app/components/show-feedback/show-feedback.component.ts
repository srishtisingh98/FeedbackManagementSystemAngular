import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Program } from 'src/app/model/program';
import { Feedback } from 'src/app/model/feedback';
@Component({
  selector: 'app-show-feedback',
  templateUrl: './show-feedback.component.html',
  styleUrls: ['./show-feedback.component.css']
})
export class ShowFeedbackComponent implements OnInit {

 // program:Program=new Program(0,new Date(),new Date(), 0)
  feedback:Feedback=new Feedback(0,0,0,0,0,0,0,'','');
  constructor(private feedbackClient:HttpClient) { 
    this.feedback;
    this.feedbackClient.get<Feedback>("http://localhost:8094/feedback/all").subscribe(
      (response)=>{this.feedback=response;
        console.log(response);});
  } 
  ngOnInit(): void {
}
}
