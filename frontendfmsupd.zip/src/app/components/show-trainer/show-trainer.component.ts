import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';

@Component({
  selector: 'app-show-trainer',
  templateUrl: './show-trainer.component.html',
  styleUrls: ['./show-trainer.component.css']
})
export class ShowTrainerComponent implements OnInit {

  employee:Employee=new Employee(0,'','', '');
  constructor(private employeeClient:HttpClient) {}

  public employeeInfo(employeeId:string){
    this.employee= new Employee(0,'','','');
    this.employeeClient.get<Employee>("http://localhost:8094/employee/get/"+employeeId).subscribe((response)=>{this.employee=response});
  }

  ngOnInit(): void {
  }

}
