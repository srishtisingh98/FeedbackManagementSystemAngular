import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Course } from 'src/app/model/course';

@Component({
  selector: 'app-show-course',
  templateUrl: './show-course.component.html',
  styleUrls: ['./show-course.component.css']
})
export class ShowCourseComponent implements OnInit {

  course:Course=new Course(0,'','',0);
  constructor(private employeeClient:HttpClient) {}

  public employeeInfo(courseId:string){
    this.course= new Course(0,'','',0);
    this.employeeClient.get<Course>("http://localhost:8094/course/get/"+courseId).subscribe((response)=>{this.course=response});
  }
  ngOnInit(): void {
  }

}
