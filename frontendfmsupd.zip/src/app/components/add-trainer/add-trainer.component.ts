import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { Role } from 'src/app/role';
import { EmployeeService } from 'src/app/service/employee-service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-trainer',
  templateUrl: './add-trainer.component.html',
  styleUrls: ['./add-trainer.component.css']
})
export class AddTrainerComponent implements OnInit {

//   participant:Employee= new Employee(0,'','',Role.FACULTY);
  createdFlag:boolean=false;
//   service:EmployeeService;
//   constructor( service:EmployeeService) { this.service=service;}
//   add(data:any){
//     this.participant= new Employee(data.employeeId,data.empName,data.password,data.role);
//     this.participant.password=data.password;
//     console.log('adding: '+this.participant);
//     this.service.addEmployee(this.participant);

  

  employee: Employee;
  employeeServ:EmployeeService;
  router:Router;
  // books:Array<Book>=[];

  constructor(employeeServ: EmployeeService, router:Router) { 
    this.employee= new Employee(0, "", "", "");
    this.employeeServ = employeeServ;
    this.router = router;
  }

  ngOnInit(): void {
  }

  addEmployee(f:any){
    if(this.employeeServ.idExists(f.value.id)){
      alert('Id already exist');
    }else{
      this.createdFlag=true;
      this.employeeServ.employees.push(f.value);
      this.router.navigate([
        'show-trainer'
        
      ]);
      console.log(f);
    }

  }

 }
