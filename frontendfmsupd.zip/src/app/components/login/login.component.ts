import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  // data:any;
  // success:boolean = false;
  // employeeServ:EmployeeService;
  // router:Router;
  // constructor(router:Router, employeeServ : EmployeeService) {
  //   this.router = router;
  //   this.employeeServ = employeeServ;
  //  }

  ngOnInit(): void {
  }
  
  // loginUser(fm:any){
  //   this.data = new Employee(fm.value.id,"",fm.value.password,"");
  //   this.employeeServ.login(this.data);
  //   setTimeout(
  //     ()=>{

  //       console.log(this.data);
  //       if(this.data.role==""){
  //         console.log("Wrong Password");
  //         this.success = true;
  //       }else{
  //         this.router.navigate([
  //           'employee-'+this.data.role
  //         ]);
  //       }
  //     }, 
  //     1000
  //   ); 

  }

  // onSubmit(data: any) {
  //   this.EmployeeService
  //     .rtoLogin(data.email, data.password)
  //     .subscribe(
  //       response => {
  //         this.authResponse = response.msg;
  //         if (response.status) {
  //           console.log(this.authResponse);
  //           this.rtoService.redirectDashboard(this.authResponse);
  //         }
  //       },
 

  // }
