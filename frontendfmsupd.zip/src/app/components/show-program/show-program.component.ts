import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Course } from 'src/app/model/course';
import { Employee } from 'src/app/model/employee';
import { Program } from 'src/app/model/program';

@Component({
  selector: 'app-show-program',
  templateUrl: './show-program.component.html',
  styleUrls: ['./show-program.component.css']
})
export class ShowProgramComponent implements OnInit {
 course: Course = new Course(0,'','',0);
 employee: Employee = new Employee(0,'','','');
 program:Program=new Program(0,new Date(),new Date(), this.course, this.employee )

  constructor(private programClient:HttpClient) { 
    this.programClient.get<Program>("http://localhost:8083/program/all").subscribe(
      (response)=>{this.program=response;
        console.log(response);});
  } 
  ngOnInit(): void {
}

}
