import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Program } from 'src/app/model/program';
import { ParticipantService } from 'src/app/service/participant-service';

@Component({
  selector: 'app-participant-dashboard',
  templateUrl: './participant-dashboard.component.html',
  styleUrls: ['./participant-dashboard.component.css']
})
export class ParticipantDashboardComponent implements OnInit {

  router: Router;
  program: Program;
  participantServ : ParticipantService;
  constructor(router: Router, participantServ: ParticipantService, program: Program) { 
  this.router = router;
  this.program = program;
  this.participantServ = participantServ;
  }
  ngOnInit(): void {
  }
  
  onSubmit(data: any) {
   // if(this.participantServ.idExists(data.value.id)){
      this.router.navigate([
        '/give-feedback'])}
     
    }

