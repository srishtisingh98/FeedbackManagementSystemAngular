import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee-service';
import { ProgramService } from 'src/app/service/program-service';

@Component({
  selector: 'app-employee-faculty',
  templateUrl: './employee-faculty.component.html',
  styleUrls: ['./employee-faculty.component.css']
})
export class EmployeeFacultyComponent implements OnInit {

  employee:any;
  router:Router;
  success : Boolean= false;
  constructor(private employeeServ : EmployeeService, router:Router) { 
  this.router= router;
  }

  ngOnInit(): void {
  }

  loginEmployee(data: any) {
    this.employee = new Employee(data.value.id, "", data.value.password, "");
    this.employeeServ.loginEmployee(this.employee)
    console.log(this.employee);
    setTimeout(
      ()=>{

        console.log(this.employee);
        if(this.employee.role==""){
          console.log("Wrong Password");
          this.success = true;
        } if(this.employee.role == "FACULTY") {
            this.router.navigate([
            '/faculty-dashboard'
          ]);
        }
      }, 
      1000
    ); 
}

}