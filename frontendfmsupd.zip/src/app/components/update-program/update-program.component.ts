import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from 'src/app/model/course';
import { Employee } from 'src/app/model/employee';
import { Program } from 'src/app/model/program';
import { ProgramService } from 'src/app/service/program-service';

@Component({
  selector: 'app-update-program',
  templateUrl: './update-program.component.html',
  styleUrls: ['./update-program.component.css']
})
export class UpdateProgramComponent implements OnInit {

  router:Router;
  course: Course = new Course(0,'','',0);
  employee: Employee = new Employee(0,'','','');
  program=new Program(0, new Date(), new Date(),this.course, this.employee);
  
  constructor( private programService:ProgramService, router:Router) {
   this.router = router;

  }

  ngOnInit(): void {
    
  }
  updateProgram(program: Program){
    if(this.programService.idExists(program)){
       alert('Program updated successfully');
       this.router.navigate([
        'show-program'
      ]);
    }
    else{
      alert("Program not found");
      this.router.navigate([
        'show-program'
      ]);
    }
  
  }
}