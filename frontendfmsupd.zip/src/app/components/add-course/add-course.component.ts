import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../../model/course';
import { CourseService} from '../../service/course-service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  course: Course;
  router:Router;
  success : Boolean = false;
  constructor(private courseServ : CourseService, router:Router, course: Course) { 
  this.router= router;
  this.course = new Course (0, '','', 0) ;
  }

  ngOnInit(): void {
  }

  addCourse(data:any){
    //this.course = new Course(0,data.value.courseDescription, data.value.courseName, data.value.noOfDays);
    if(this.courseServ.idExists(data.value.courseId)){
      alert('Id already exist');
    }else{
      this.courseServ.courses.push(data.value);
      this.router.navigate([
        'show-course'
      ]);
      console.log(data);
    }
  }
    
}
   
