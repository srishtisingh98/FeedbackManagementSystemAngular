import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Course } from '../model/course';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  surveyor:Course= new Course(0,'','',0);
  surveyors:Course[]=[];
  http:HttpClient;
  constructor(http:HttpClient){this.http=http;}

  
    courses:Array<Course>=[];
    idExists(id: any):boolean {
        if(this.courses.find(b=>b.courseId==id)){
            return true;
        }
        return false;
    }

    
  updateCourse(surveyor: Course) {
      const headers = { 'content-type': 'application/json'};
      const body=JSON.stringify(surveyor);  
      console.log('---------');
      console.log(body);
      this.http.post('http://localhost:8083/course/update',body,{'headers':headers}).subscribe(
          data=>{
            let dataVal = Object.values(data);
            surveyor.courseId=dataVal[0];
          }
        );
    }

  getCourse(surveyorId: any): Course {
      this.http.get<Course>("http://localhost:8083/course/find/id/"+surveyorId).subscribe((response)=>{this.surveyor=response});
      return this.surveyor;
    }

  // getCourses():Course[]{
  //     return this.surveyors;
  // }

  // fetchCourses(){
  //     this.surveyors=[];
  //     this.http.get<Course[]>("http://localhost:8083/course/find/all").subscribe(data=>{this.convert(data);});
  // }
  
  // convert(data:any){
  //     for(let s of data){
  //         let surveyor:Course= new Course(s.courseId,s.courseName,s.courseDescription,s.noOfDays);
  //         // if(s.createdSurveys.length>0){
  //         //    for(let survey of s.createdSurveys){
  //         //     surveyor.surveyList.push(survey.id);
  //         //    }
  //         // }
  //         this.surveyors.push(surveyor);
  //      }
  //    }

  // sendPost(surveyor:any){
  //     const headers = { 'content-type': 'application/json'};
  //     const body=JSON.stringify(surveyor);  
  //     console.log('---------');
  //     console.log(body);
      
  //     let id=surveyor.employeeId;
  //     this.http.post('http://localhost:8083/course/add',body,{'headers':headers}).subscribe(
  //         data=>{
  //           let dataVal = Object.values(data);
  //           surveyor.id=dataVal[0];
  //         }
  //       );

       
  }


