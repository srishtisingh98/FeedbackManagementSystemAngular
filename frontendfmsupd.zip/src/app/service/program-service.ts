import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Program } from "../model/program";
//import { BasicResponse } from "../types/types";


@Injectable ({
    providedIn: 'root'
})

export class ProgramService{

  constructor(private http:HttpClient){
    
  }
    
  addProgram(program: Program){
    const headers = { 'content-type': 'application/json'};
        const body=JSON.stringify(program);  
        console.log('---------');
        console.log(body);
         this.http.post<Program>('http://localhost:8083/program/add' ,body,{'headers':headers}).subscribe(
           f=>{program.trainingId = f.trainingId}
         );
  }
  // getProgram(surveyorId: any): Program {
  //   this.http.get<Program>("http://localhost:8083/program/findById/"+surveyorId).subscribe((response)=>{this.surveyor=response});
  //   return this.surveyor;
  // }

  program:Array<Program>=[];
  idExists(id: any):boolean {
      if(this.program.find(b=>b.trainingId==id)){
          return true;
      }
      return false;
    }
  // sendProgram(surveyor:any){
  //   const headers = { 'content-type': 'application/json'};
  //   const body=JSON.stringify(surveyor);  
  //   console.log('---------');
  //   console.log(body);
    
  //   let id=surveyor.employeeId;
  //   this.http.post('http://localhost:8083/program/add',body,{'headers':headers}).subscribe(
  //       data=>{
  //         let dataVal = Object.values(data);
  //         surveyor.id=dataVal[0];
  //       }
  //     );

    }
