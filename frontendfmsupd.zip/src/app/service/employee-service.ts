import { Injectable } from "@angular/core";
import { Employee } from "../model/employee";
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { BasicResponse } from "../types/types";
import { Role } from "../role";
// const httpOptions = {
//   headers: new HttpHeaders({
//     'Content-Type': 'application/json'
//   })
//  };
// const localUrlBase = 'http://localhost:8083/employee';
// const login = localUrlBase + "/signIn";

  
@Injectable({
    providedIn: 'root'
})

export class EmployeeService {

  constructor(private http:HttpClient){
    
  }

  employees:Array<Employee>=[];
  idExists(id: any):boolean {
      if(this.employees.find(b=>b.employeeId==id)){
          return true;
      }
      return false;
  }

  addEmployee(employee: Employee){
    const headers = { 'content-type': 'application/json'};
        const body=JSON.stringify(employee);  
        console.log('---------');
        console.log(body);
         this.http.post<Employee>('http://localhost:8083/Employee/add' ,body,{'headers':headers}).subscribe(
           data=>{employee.employeeId = data.employeeId}
         );
  }
  


  loginEmployee(employee: any) { 
    const headers = { 'content-type': 'application/json'};
    const body=JSON.stringify(employee);  
    console.log('---------');
    console.log(body);
     this.http.get("http://localhost:8083/Employee/signIn/" + employee.employeeId).subscribe(
       data=>{
         let dataVal = Object.values(data);
        employee.role=dataVal[3];
        console.log(data)

       }
     );

      }
    }

  // addTrainer(employee:Employee){
  //   this.employee.push(employee);
  //   this.sendPost(surveyor);

  
 
  // signinEmployee(id: number, password:string ){
  //  // const headers = { 'content-type': 'application/json'};
  //  return this.http.post<BasicResponse>(login, { employeeId : id, password: password })  
  // }

  // redirectDashboard(token: string) {
  //   this.token = token;
  //   localStorage.setItem("token", token);
  //   this.router.navigateByUrl("/admin-dashboard");
  // }
 