import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Program } from "../model/program";
import { BasicResponse } from "../types/types";

const localUrlBase = 'http://localhost:8083/employee';
const login = localUrlBase + "/signIn";

@Injectable({
    providedIn: 'root'
})

export class ParticipantService{

    token = "";
  constructor(private http: HttpClient, private router: Router) {
    this.token = localStorage.getItem("token") || "";
  }
  signinEmployee(id: string, password:string ){
   // const headers = { 'content-type': 'application/json'};
   return this.http.post<BasicResponse>(login, { employeeId : id, password: password })  
  }

  program:Array<Program>=[];
  idExists(trainingId: any):boolean {
      if(this.program.find(b=>b.trainingId==trainingId)){
          return true;
      }
      return false;

}
}