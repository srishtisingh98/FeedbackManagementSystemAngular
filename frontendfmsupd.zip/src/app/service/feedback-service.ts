import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Course } from "../model/course";
import { Employee } from "../model/employee";
import { Feedback } from "../model/feedback";
import { Program } from "../model/program";

@Injectable({
  providedIn: 'root'
})

export class FeedbackService {
  course:Course=new Course(0,'','',0);
  faculty:Employee=new Employee(0,'','', '');
  employee: Employee = new Employee(0,'','','');
  program:Program=new Program(0,new Date(),new Date(),this.course, this.employee);
 
  feedback:Feedback=new Feedback(0,0,0,0,0,0,0,'','');
  // participant:Participant=new Participant(0,'','',this.feedback,this.program);  
  http:HttpClient;
    constructor(http:HttpClient){this.http=http;}
    addFeedback( feedback:Feedback){
        this.sendPost(feedback);
    }
    sendPost(feedback:any){
        const headers = { 'content-type': 'application/json'};
        const body=JSON.stringify(feedback);  
        console.log('---------');
        console.log(body);
        this.http.post('http://localhost:8083/feedback/add',body,{'headers':headers}).subscribe(
            data=>{
              let dataVal = Object.values(data);
              feedback.id=dataVal[0];
            }
          );
    }
  }