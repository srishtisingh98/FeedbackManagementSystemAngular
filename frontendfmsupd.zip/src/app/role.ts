export enum Role {
    ADMIN= "ADMIN",
    FACULTY = "FACULTY",
    PARTICIPANT= "PARTICIPANT",
}
